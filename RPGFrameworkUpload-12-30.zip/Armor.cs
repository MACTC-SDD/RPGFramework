﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPGFramework
{
    public class Armor : Item
    {
        // TODO - Implement once we know how combat will work
    }
}
