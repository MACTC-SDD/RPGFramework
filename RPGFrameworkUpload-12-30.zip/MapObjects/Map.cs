﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPGFramework.MapObjects
{
    // We'll use this to create display information for the map.
    // TODO!
    public class Map
    {
    }
}
